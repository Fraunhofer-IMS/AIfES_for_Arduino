# AIfES pytools

The AIfES pytools provide some helper functions for neural network creation in AIfES.
For example you can quantize a model trained in python (e.g. with Keras or PyTorch) to the q7 integer representation.

## Installation

To install the AIfES pytools package just run ```pip install <path-to-the-package>``` in the console.